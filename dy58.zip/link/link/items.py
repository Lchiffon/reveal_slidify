# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

from scrapy.item import Item, Field



class LinkItem(scrapy.Item):
	# define the fields for your item here like:
	# name = scrapy.Field()
	title = scrapy.Field()
	link = scrapy.Field()
	desc = scrapy.Field()
	web_id = Field()
	name = Field()
	update_time = Field()
	bith_year = Field()
	gender = Field()
	mobile = Field()
	QQEmail = Field()
	info = Field()
	expect_city = Field()
	expect_post = Field()
	expect_salary = Field()
	work_expr = Field()
	work_skill = Field()
	edu_info = Field()
	curl_time = Field()
	curl_link = Field()
	pt = Field()
