# encoding: utf-8


from scrapy.item import Item, Field
from scrapy.spider import BaseSpider
from scrapy.selector import HtmlXPathSelector
#from scrapy.selector import Selector
from page import items
import time
import re
import sys

reload(sys)

sys.setdefaultencoding('utf-8')

#定义要抓取页面的爬虫类
class PageSpider(BaseSpider):
	name = "page"

	start_urls = []

	def __init__(self):
		self.start_urls = self.set_url()	

	#从link.txt文件中读出要抓取的链接列表，放入数组中
	def set_url(self):
		url_list = []
		link_file = open('../output/link_output/link.txt', 'r')
		for each_link in link_file:
			each_link = each_link.replace('\r','')
			each_link = each_link.replace('\n','')
			url_list.append(each_link)
		link_file.close()
		return url_list

	def parse(self, response):
		fileid = "".join(re.findall(r'[0-9]+',response.url))
		hxs = HtmlXPathSelector(response)
		data = self.getDefaultDataItem()

		#webid和webdesc属性是hard-code写死的
		#各位要根据自己分配的网站名称修改
		data['webid'] = "dy58"
		data['webdesc'] = "鼎源资产"
		#标名称
		data['name'] = "title"
		#标链接        
		data['tenderUrl'] = response.url
		#标编号,作为生成的json文件名 
		# tenderId = "".join(re.findall(r'[0-9]+',response.url))
		data['tenderId'] = fileid

		#标名称
		name = hxs.select('//h3/text()').extract()[0].encode('utf-8')
		data['name'] = name

		tmp = hxs.select('//td/strong/text()').extract()
		#print tmp[1]

		# 标大小
		capital = tmp[0]

		capital = capital.replace(',','')
		capital = capital.replace('.','')
		data['capital'] = capital

		# 年利率
		profit = tmp[1]
		data['profit'] = profit + "%"

		# 标期限
		timeLimit = tmp[2]
		data['timeLimit'] = timeLimit+"月"

		# 标进度
		process = hxs.select("//strong[@class='tender_completed']/text()").extract()[0]
		data['process'] = process

		# 发布时间
		data['startTime'] = ''

		# 标状态(要区分正在募集和募集完毕状态)
		if(process == '投标完成100%'):
			tenderStatus = "募集完毕"
		else:
			tenderStatus = "正在募集"
		data['tenderStatus'] = tenderStatus

		# 还款模式
		repaymentMode = hxs.select("//a[@class='m-tooltips png']/@title").extract()[0]
		data['repaymentMode'] = repaymentMode

		# 安全保障
		data['security'] = ''

		# 借款详情
		data['detail'] = ''

		# 资金用途
		data['usage'] = ''

		# 还款来源
		data['paymentSource'] = ''

		# 借款人信息/借款单位信息
		data['operateStatus'] = ''

		# 风险控制
		data['riskControl'] = ''

		# 抵押物
		data['pawn'] = ''

		# 抵押物详情
		data['pawnInfo'] = ''

		# 投资记录
		tenderRecord = hxs.select("//table[@class='ord_tab']").extract()
		data['tenderRecord'] = tenderRecord

		return data

	def getDefaultDataItem(self):
		item = items.PageItem()
		item['name'] = ""
		item['capital'] = ""
		item['profit'] = ""
		item['timeLimit'] = ""
		item['process'] = ""
		item['startTime'] = ""
		item['tenderStatus'] = ""
		item['repaymentMode'] = ""
		item['security'] = ""
		item['detail'] = ""
		item['usage'] = ""
		item['paymentSource'] = ""
		item['operateStatus'] = ""
		item['riskControl'] = ""
		item['pawn'] = ""
		item['pawnInfo'] = ""
		item['tenderRecord'] = ""
		item['tenderId'] = ""
		item['tenderUrl'] = ""
		return item
	
	def formatAry2Str(self, p1):
		t1 = ""
		for n1 in p1:
			t1 = t1 + n1.encode('utf-8')
		return t1


