# encoding: utf-8

from scrapy.spider import BaseSpider
from scrapy.selector import HtmlXPathSelector
import re

#定义爬虫的业务逻辑实现类
class LinkSpider(BaseSpider):
	name = "link"
	start_urls = []

	def __init__(self):
		self.start_urls = self.set_url()

	#set_url方法动态设定要抓取的链接列表
	#是各位要修改代码的部分
	def set_url(self):
		url_list = []
		url_list.append("http://www.dy58.com/user/showRecommend.do")
		return url_list


	#parse方法从html源代码中解析要抓取的内容
	#是各位要修改代码的部分
	def parse(self, response):

		hxs = HtmlXPathSelector(response)
		links = hxs.select('//td/a[@class="f14 col_blue"]/@onclick').extract()
		newlink = ''

		for link in links:
			a,b = re.findall(r'[0-9]+',link)
			link = "http://www.dy58.com/bid/showbidinfo.do?bidid="+a+"&bizid="+b
			newlink = link + '\r\n'
			open('../output/link_output/link.txt', 'ab').write(newlink)


