# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

from scrapy.item import Item, Field



class PageItem(Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    webid = Field() #网站ID
    webdesc = Field() #网站描述
    name = Field()  # 标名称
    capital = Field()  # 标大小
    profit = Field()   # 年利率
    timeLimit = Field()   # 标期限
    process = Field()  # 标进度
    startTime = Field()   # 发布时间
    tenderStatus = Field()   # 标状态
    repaymentMode = Field()  # 还款模式
    security = Field()   # 安全保障
    detail = Field()  # 借款详情
    usage = Field()  # 资金用途
    paymentSource = Field()   # 还款来源
    operateStatus = Field()  # 借款人信息/借款单位信息
    riskControl = Field()  # 风险控制
    pawn = Field()   # 抵押物
    pawnInfo = Field()   # 抵押物详情
    tenderRecord = Field()  # 投资记录
    tenderId = Field()  # 标编号
    tenderUrl = Field()   # 标链接

