# encoding: utf-8

class PagePipeline(object):

    #把解析后的内容放入文件中
    def process_item(self, item, spider):
        fname = '../output/page_output/' + item['tenderId'] + '.json'
        outfile = open(fname, 'wb')
        json_patten = """
{
  "name":"%s", 
  "capital":%s, 
  "profit":%s, 
  "timeLimit":"%s", 
  "process":"%s",
  "startTime":"%s", 
  "tenderStatus":"%s",
  "repaymentMode":"%s",
  "security":"%s", 
  "detail":"%s", 
  "usage":"%s", 
  "paymentSource":"%s", 
  "operateStatus":"%s", 
  "riskControl":"%s", 
  "pawn":"%s", 
  "pawnInfo":"%s", 
  "tenderRecord":"%s", 
  "tenderId":"%s", 
  "tenderUrl":"%s" 
}
"""
        outfile.write(json_patten % (item['name'], item['capital'], item['profit'], item['timeLimit'], item['process'], item['startTime'],item['tenderStatus'],item['repaymentMode'],item['security'],item['detail'],item['usage'],item['paymentSource'],item['operateStatus'],item['riskControl'],item['pawn'],item['pawnInfo'],item['tenderRecord'],item['tenderId'],item['tenderUrl']))

